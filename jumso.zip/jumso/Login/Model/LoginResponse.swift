import Foundation

struct LoginResponse: Codable {
    let email: String
    let name: String
    let nickname: String
}
