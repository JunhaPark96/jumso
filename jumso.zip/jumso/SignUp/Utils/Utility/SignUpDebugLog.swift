
import SwiftUI

class SignUpDebugLog {
    static func debugLog(_ message: String) {
        print("[SignUp DEBUG] \(message)")
    }
}
